package com.wshon.spring.framework.rce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFrameworkRceApplicationTests {

    @Test
    void contextLoads() {
    }

}
