package com.wshon.spring.framework.rce;

/**
 * @ClassName: demo
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/4 21:28
 * @Version: v1.0.0
 * @Description:
 **/
public class demo1 {
    public static void main(String[] args) {
        String str = ".class.module.classLoader";
        String prefix = ".";
        System.out.println(str.indexOf(prefix) );
        System.out.println(str.substring(str.indexOf(prefix) + 1));
        int k = 1;
        String value = "";
        while(k <= 10 && value == ""){
            ++k;
            System.out.println("kasdddddddasdsa");
            if (k==3)
            value= "asd";
        }
    }
}
