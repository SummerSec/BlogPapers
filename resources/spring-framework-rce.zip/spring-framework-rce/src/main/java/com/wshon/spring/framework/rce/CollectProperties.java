/**
 * @author lz520520
 * @date 2022/3/31 9:59
 */

package com.wshon.spring.framework.rce;

import org.springframework.beans.BeanWrapperImpl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class CollectProperties {
    /* Find all the "set" methods that accept exactly one parameter (String,
     ** boolean or int) in the given Object, or in Objects that can be reached via
     ** "get" methods (without parameters) in a recursive way
     **
     ** Params:
     ** - Object instance : Object to process
     ** - javax.servlet.jsp.JspWriter out : Where the results will be printed
     ** - java.util.HashSet set : Set of previously processed Objects
     ** - String poc : Chain of previously called getters to reach current object
     ** - int level : Current level of recursion
     ** - boolean debug: print extra debug information for candidates
     */
    Object initarget;
    String prefix = ".";
    public CollectProperties(HttpServletRequest request, HttpServletResponse response) throws Exception{
        /*
         ** MAIN METHOD
         */
        PrintWriter out = response.getWriter();
        java.util.HashSet set = new java.util.HashSet<Object>();

        String pocParam = request.getParameter("poc");
        String poc = (pocParam != null) ? pocParam : "";

// Struts 2.x Action
        this.initarget = this;

// Struts 1.x ActionForm
//LoginForm initarget = new LoginForm();

// Get the target Object as described by poc
        Object target = applyGetChain(initarget, poc);

// Check for debug mode
        String mode = request.getParameter("debug");
        boolean debug = false;

        if((mode != null) && (mode.equalsIgnoreCase("true"))) {
            debug = true;
        }

// Switch the command to be executed
        String cmd = request.getParameter("cmd");

        if(cmd != null) {
            if(cmd.equalsIgnoreCase("all")) {

                printAllMethodsNames(target, out);

            } else if(cmd.equalsIgnoreCase("allp")) {

                printAllMethodsWithNumParams(target, out);

            } else if(cmd.equalsIgnoreCase("meth")) {

                printMethods(target, out);

            } else {

                processClass(target, out, set, poc, 0, debug);

            }
        } else {
            processClass(target, out, set, poc, 0, debug);
        }

    }
    public void processClass(
            Object instance,
            PrintWriter out,
            java.util.HashSet set,
            String poc,
            int level,
            boolean debug) {

        if (++level > 15) {
            return;
        }

        Class<?> c = instance.getClass();
        set.add(instance);
        Method[] allMethods = c.getMethods();
//        c.getSuperclass().getMethods()
        /* Print all set methods that match the desired properties:
         ** - exactly 1 parameter (String, boolean or int)
         ** - public modifier
         */
        for (Method m : allMethods) {
            if (!m.getName().startsWith("set")) {
                continue;
            }

            if (!m.toGenericString().startsWith("public")) {
                continue;
            }

            Class<?>[] pType  = m.getParameterTypes();
            if(pType.length!=1) continue;

            if(pType[0].getName().equals("java.lang.String")
                    || pType[0].getName().equals("boolean")
                    || pType[0].getName().equals("int")) {

                String fieldName = m.getName().substring(3,4).toLowerCase()
                        + m.getName().substring(4);

                /* Print the chain of getters plus the candidate setter in a
                 ** format that can be directly used as a PoC for the Struts
                 ** vulnerability. Also print the fqdn class name of the
                 ** current Object if debug mode is 'on'.
                 */
                if (debug) {
                    out.print("-------------------------" + c.getName() + "\n");
                    out.print("Candidate: " + poc + "." + fieldName + "\n");
                }
                else {
                    BeanWrapperImpl bw = new BeanWrapperImpl(this.initarget);
                    String propertyName = poc + "." + fieldName;
                    Integer offset = propertyName.indexOf(prefix);
                    if (offset != -1) {
                        propertyName = propertyName.substring(offset + prefix.length());
                    }
                    String value = "";
                    String type = "";
                    try {
                        BeanWrapperImpl bwl = (BeanWrapperImpl)invoke(bw, "getPropertyAccessorForPropertyPath", propertyName);
                        // TODO: 这里存在私有属性和getter对应不上，应该不算bean，默认还是通过私有属性反射
                        Object v = getFieldValue(bwl.getWrappedInstance(), fieldName);

                        value = v.toString();
                        type = v.getClass().getName();
                    } catch (Exception  e) {
                        value = "";
                    }
                    if (value.equals("")) {
                        try {
                            BeanWrapperImpl bwl = (BeanWrapperImpl)invoke(bw, "getPropertyAccessorForPropertyPath", propertyName);
                            Object v = invoke(bwl.getWrappedInstance(), "get" +captureName(fieldName));
                            value = v.toString();
                            type = v.getClass().getName();
                        }catch (Exception e) {
                            value = "";
                        }

                    }
                    out.print(String.format("%s = %s  (%s)\n", propertyName, value, type));
                }
                out.flush();
            }
        }

        /* Call recursively the current function against (not yet processed)
         ** Objects that can be reached using public get methods of the current
         ** Object (without parameters)
         */
        for (Method m : allMethods) {
            if (!m.getName().startsWith("get")) {
                continue;
            }

            if (!m.toGenericString().startsWith("public")) {
                continue;
            }

            Class<?>[] pType  = m.getParameterTypes();
            if(pType.length!=0) continue;
            if(m.getReturnType() == Void.TYPE) continue;

            /* In case of problems with reflection use
             ** m.setAccessible(true);
             */
            Object o;
            try {
                m.setAccessible(true);
                o = m.invoke(instance);
            } catch (Exception e) {
                continue;
            }
            if(o!=null)
            {
                if(set.contains(o)) continue;
//
//
//                String fieldName = m.getName().substring(3,4).toLowerCase()
//                        + m.getName().substring(4);
//                if (debug) {
//                    out.print("-------------------------" + c.getName() + "\n");
//                    out.print("Candidate: " + poc + "." + fieldName + "\n");
//                }
//                else {
//                    BeanWrapperImpl bw = new BeanWrapperImpl(this.initarget);
//                    String propertyName = poc + "." + fieldName;
//                    Integer offset = propertyName.indexOf(prefix);
//                    if (offset != -1) {
//                        propertyName = propertyName.substring(offset + prefix.length());
//                    }
//                    String value = "";
//                    String type = "";
//                    try {
//                        BeanWrapperImpl bwl = (BeanWrapperImpl)invoke(bw, "getPropertyAccessorForPropertyPath", propertyName);
//                        // TODO: 这里存在私有属性和getter对应不上，应该不算bean，默认还是通过私有属性反射
//                        Object v = getFieldValue(bwl.getWrappedInstance(), fieldName);
//
//                        value = v.toString();
//                        type = v.getClass().getName();
//                    } catch (Exception  e) {
//                        value = "";
//                    }
//                    if (value.equals("")) {
//                        try {
//                            BeanWrapperImpl bwl = (BeanWrapperImpl)invoke(bw, "getPropertyAccessorForPropertyPath", propertyName);
//                            Object v = invoke(bwl.getWrappedInstance(), "get" +captureName(fieldName));
//                            value = v.toString();
//                            type = v.getClass().getName();
//                        }catch (Exception e) {
//                            value = "";
//                        }
//
//                    }
//                    out.print(String.format("%s = %s  (%s)\n", propertyName, value, type));
//                }
//                out.flush();


                processClass(o,out, set, poc + "."
                        + m.getName().substring(3,4).toLowerCase()
                        + m.getName().substring(4), level, debug);
            }
        }
    }

    /*
     ** Print all the method names of a given Object
     */
    public void printAllMethodsNames(
            Object instance,
            PrintWriter out) throws Exception {

        Method[] allMethods = instance.getClass().getMethods();
        for (Method m : allMethods) {
            out.print(m.getName() + "\n");
        }
    }

    /* Print all the method names of a given Object and the number of parameters
     ** that it has
     */
    public void printAllMethodsWithNumParams(
            Object instance,
            PrintWriter out) throws Exception {

        Method[] allMethods = instance.getClass().getMethods();
        for (Method m : allMethods) {
            Class<?>[] pType = m.getParameterTypes();

            out.print("Method: " + m.getName() + " with " + pType.length
                    + " parameters\n");
        }
    }

    /* Print the "set" methods that accept exactly one parameter (String,
     ** boolean or int) and the "get" methods (without parameters) in the given
     ** Object
     */
    public void printMethods(
            Object instance,
            PrintWriter out) throws Exception {

        Method[] allMethods = instance.getClass().getMethods();
        for (Method m : allMethods) {

            Class<?>[] pType = m.getParameterTypes();

            if(m.getName().startsWith("get")
                    && m.toGenericString().startsWith("public")) {

                Class<?> returnType = m.getReturnType();

                if(pType.length == 0) {

                    out.print("GET method: " + m.getName() + " of class"
                            + instance.getClass().getName() + " returns "
                            + returnType.getName() + "\n");
                }
            }

            if(m.getName().startsWith("set")
                    && m.toGenericString().startsWith("public")) {

                if((pType.length == 1) && (pType[0].getName().equals("java.lang.String")
                        || pType[0].getName().equals("boolean")
                        || pType[0].getName().equals("int"))) {

                    out.print("SET method: " + m.getName() + " of class"
                            + instance.getClass().getName() + " with param "
                            + pType[0].getName() + "\n");
                }
            }
        }
    }

    /* Return the Object that results of resolving the chain of getters described
     ** by the "poc" parameter
     */
    public Object applyGetChain(
            Object initarget,
            String poc) throws Exception {

        if(poc.equals("")) {
            return initarget;
        }

        String[] parts = poc.split("\\.");

        String method = "get" + parts[0].substring(0,1).toUpperCase();

        if(parts[0].length() > 1) {
            method += parts[0].substring(1);
        }

        Class<?> c = initarget.getClass();
        Method m = c.getMethod(method, null);

        /* In case of problems with reflection use
         ** m.setAccessible(true);
         */
        Object o = m.invoke(initarget);

        if(parts.length == 1) {
            return o;
        }

        String newPoc = parts[1];

        for(int i=2; i<parts.length; i++) {
            newPoc.concat("." + parts[i]);
        }

        return applyGetChain(o, newPoc);
    }

    // 反射设置属性
    public static void setFieldValue(Object obj, String fieldName, Object value) throws Exception {
        Field f = null;
        if (obj instanceof Field) {
            f = (Field) obj;
        } else {
            f = obj.getClass().getDeclaredField(fieldName);
        }

        f.setAccessible(true);
        f.set(obj, value);
    }
    // 反射获取属性
    public static Object getFieldValue(Object obj, String fieldName) throws Exception {
        Field f = null;
        if (obj instanceof Field) {
            f = (Field) obj;
        } else {
            Method method = null;
            Class cs = obj.getClass();

            while (cs != null) {
                try {
                    f = cs.getDeclaredField(fieldName);
                    cs = null;
                } catch (Exception var6) {
                    cs = cs.getSuperclass();
                }
            }
        }

        f.setAccessible(true);
        return f.get(obj);
    }
    // 反射调用方法
    public static Object invoke(Object obj, String methodName, Object... parameters) throws Exception {
        ArrayList classes = new ArrayList();
        if (parameters != null) {
            for (int i = 0; i < parameters.length; ++i) {
                Object o1 = parameters[i];
                if (o1 != null) {
                    classes.add(o1.getClass());
                } else {
                    classes.add((Object) null);
                }
            }
        }

        Method method = getMethodByClass(obj.getClass(), methodName, (Class[]) classes.toArray(new Class[0]));
        return method.invoke(obj, parameters);

    }
    // 获取class里的反射方法
    public static Method getMethodByClass(Class cs, String methodName, Class... parameters) {
        Method method = null;

        while (cs != null) {
            try {
                method = cs.getDeclaredMethod(methodName, parameters);
                cs = null;
            } catch (Exception var6) {
                cs = cs.getSuperclass();
            }
        }
        if (method != null) {
            method.setAccessible(true);
        }
        return method;
    }
    /**
     * 将字符串的首字母转大写
     * @param str 需要转换的字符串
     * @return
     */
    private static String captureName(String str) {
        // 进行字母的ascii编码前移，效率要高于截取字符串进行转换的操作
        char[] cs=str.toCharArray();
        cs[0]-=32;
        return String.valueOf(cs);
    }
}
