package com.wshon.spring.framework.rce;

import org.springframework.beans.BeanWrapperImpl;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * @ClassName: BeanT
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/11 20:37
 * @Version: v1.0.0
 * @Description:
 **/
public class BeanT {
    public static void main(String[] args) throws InvocationTargetException, IllegalAccessException {
        BeanWrapperImpl bwl = new BeanWrapperImpl(new School());
        bwl.setAutoGrowNestedPaths(true); //自动属性嵌套
        bwl.setPropertyValue("name", "北京大学");
        bwl.setPropertyValue("student.name", "张三");
        PropertyDescriptor[] pds = bwl.getPropertyDescriptors();
        Set<String> propertyNames = new HashSet<String>();
        for (PropertyDescriptor pd : pds) {
            //获取属性名称
            System.out.println(pd.getName() + " : " + "" + pd.getPropertyType() + " : " + pd.getReadMethod().invoke(bwl.getWrappedInstance()));
            propertyNames.add(pd.getName());
        }
        System.out.println(Arrays.toString(propertyNames.toArray(new String[propertyNames.size()])));

    }
}
