package com.wshon.spring.framework.Introspection;

/**
 * @ClassName: TestBean
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/11 20:18
 * @Version: v1.0.0
 * @Description:
 **/
public class TestBean {
    public String name;
    public BeanA beanA;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BeanA getBeanA() {
        return beanA;
    }

    public void setBeanA(BeanA beanA) {
        this.beanA = beanA;
    }
}
