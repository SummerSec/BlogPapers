package com.wshon.spring.framework.rce;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.InitBinder;

/**
 * @ClassName: GlobalControllerAdvice
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/10 14:10
 * @Version: v1.0.0
 * @Description:
 **/
@ControllerAdvice
@Order(Ordered.LOWEST_PRECEDENCE)
public class GlobalControllerAdvice {
//    @InitBinder
//    public void setAllowedFields(WebDataBinder dataBinder){
//        String[] abd= new String[]{"class.*","Class.*","*.class.*","*.Class.*"};
//        dataBinder.setDisallowedFields(abd);
//    }
}
