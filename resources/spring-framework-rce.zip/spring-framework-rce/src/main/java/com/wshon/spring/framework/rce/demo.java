package com.wshon.spring.framework.rce;

import org.springframework.beans.AbstractNestablePropertyAccessor;
import org.springframework.beans.BeanWrapperImpl;

import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * @ClassName: demo
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/6 16:32
 * @Version: v1.0.0
 * @Description:
 **/
public class demo {
//    Object initarget ;
    public void processClass(
            Object instance,
            PrintStream out,
            java.util.HashSet set,
            String poc,
            int level,
            boolean debug) {

        if (++level > 15) {
            return;
        }
        Class<?> c = instance.getClass();
        set.add(instance);
        Method[] allMethods = c.getMethods();

        /* Print all set methods that match the desired properties:
         ** - exactly 1 parameter (String, boolean or int)
         ** - public modifier
         */
        for (Method m : allMethods) {
            if (!m.getName().startsWith("set")) {
                continue;
            }
            if (!m.toGenericString().startsWith("public")) {
                continue;
            }
            Class<?>[] pType  = m.getParameterTypes();
            if(pType.length!=1) continue;

            if(pType[0].getName().equals("java.lang.String")
                    || pType[0].getName().equals("boolean")
                    || pType[0].getName().equals("int")) {

                String fieldName = m.getName().substring(3,4).toLowerCase()
                        + m.getName().substring(4);

                /* Print the chain of getters plus the candidate setter in a
                 ** format that can be directly used as a PoC for the Struts
                 ** vulnerability. Also print the fqdn class name of the
                 ** current Object if debug mode is 'on'.
                 */


                BeanWrapperImpl bw = new BeanWrapperImpl(instance);
                String value = "";
                String type = "";
                try {
                    Object v = getFieldValue(bw.getWrappedInstance(), fieldName);
                    value = v.toString();
                    type = v.getClass().getName();
                    if (value  == "") {
                        BeanWrapperImpl bwl = ((BeanWrapperImpl) ((AbstractNestablePropertyAccessor) invoke(bw, "getPropertyAccessorForPropertyPath", fieldName)));
                        v = getFieldValue(bwl.getWrappedInstance(),  fieldName);
                        value = v.toString();
                        type = v.getClass().getName();
                    }
                }catch (Exception e){
                    value = "";
                }
                String temp = poc + "." + fieldName + "  =  " + value + " (" + type + ") ";
                temp = temp.indexOf(".") == 0 ? temp.substring(1) : temp;
                if (debug) {
                    out.print("-------------------------" + c.getName() + "<br>");
                    out.print("Candidate: " + temp + "<br>");
                }
                else {
                    out.println( temp +  "<br>");
                }
                out.flush();
            }
        }
        /* Call recursively the current function against (not yet processed)
         ** Objects that can be reached using public get methods of the current
         ** Object (without parameters)
         */
        for (Method m : allMethods) {
            if (!m.getName().startsWith("get")) {
                continue;
            }
            if (!m.toGenericString().startsWith("public")) {
                continue;
            }
            Class<?>[] pType  = m.getParameterTypes();
            if(pType.length!=0) continue;
            if(m.getReturnType() == Void.TYPE) continue;
            /* In case of problems with reflection use
             ** m.setAccessible(true);
             */
            Object o = null;
            try {
                m.setAccessible(true);
                 o = m.invoke(instance);
            }catch (Exception e) {
//                e.printStackTrace();
            }

            if(o!=null)
            {
                if(set.contains(o)) continue;

                processClass(o,out, set, poc + "."
                        + m.getName().substring(3,4).toLowerCase()
                        + m.getName().substring(4), level, debug);
            }
        }
    }
    /*
     ** Print all the method names of a given Object
     */
    public void printAllMethodsNames(
            Object instance,
            PrintStream out) throws Exception {
        Method[] allMethods = instance.getClass().getMethods();
        for (Method m : allMethods) {
            out.print(m.getName() + "<br>");
        }
    }
    /* Print all the method names of a given Object and the number of parameters
     ** that it has
     */
    public void printAllMethodsWithNumParams(
            Object instance,
            PrintStream out) throws Exception {
        Method[] allMethods = instance.getClass().getMethods();
        for (Method m : allMethods) {
            Class<?>[] pType = m.getParameterTypes();
            out.print("Method: " + m.getName() + " with " + pType.length
                    + " parameters<br>");
        }
    }
    /* Print the "set" methods that accept exactly one parameter (String,
     ** boolean or int) and the "get" methods (without parameters) in the given
     ** Object
     */
    public  void printMethods(
            Object instance,
            PrintStream out) throws Exception {
        Method[] allMethods = instance.getClass().getMethods();
        for (Method m : allMethods) {

            Class<?>[] pType = m.getParameterTypes();
            if(m.getName().startsWith("get")
                    && m.toGenericString().startsWith("public")) {

                Class<?> returnType = m.getReturnType();
                if(pType.length == 0) {

                    out.print("GET method: " + m.getName() + " of class"
                            + instance.getClass().getName() + " returns "
                            + returnType.getName() + "<br>");
                }
            }
            if(m.getName().startsWith("set")
                    && m.toGenericString().startsWith("public")) {

                if((pType.length == 1) && (pType[0].getName().equals("java.lang.String")
                        || pType[0].getName().equals("boolean")
                        || pType[0].getName().equals("int"))) {

                    out.print("SET method: " + m.getName() + " of class"
                            + instance.getClass().getName() + " with param "
                            + pType[0].getName() + "<br>");
                }
            }
        }
    }
    /* Return the Object that results of resolving the chain of getters described
     ** by the "poc" parameter
     */
    public static Object applyGetChain(
            Object initarget,
            String poc) throws Exception {

        if(poc.equals("")) {
            return initarget;
        }
        String[] parts = poc.split("\\.");
        String method = "get" + parts[0].substring(0,1).toUpperCase();
        if(parts[0].length() > 1) {
            method += parts[0].substring(1);
        }
        Class<?> c = initarget.getClass();
        Method m = c.getMethod(method, null);
        /* In case of problems with reflection use
         ** m.setAccessible(true);
         */
        Object o = m.invoke(initarget);
        if(parts.length == 1) {
            return o;
        }
        String newPoc = parts[1];
        for(int i=2; i<parts.length; i++) {
            newPoc.concat("." + parts[i]);
        }
        return applyGetChain(o, newPoc);
    }

    private static Object invoke(BeanWrapperImpl bw, String getPropertyAccessorForPropertyPath, String propertyName) {
        try {
            Method method = AbstractNestablePropertyAccessor.class.getDeclaredMethod(getPropertyAccessorForPropertyPath, String.class);
            //            Method method = bw.getClass().getDeclaredMethod(getPropertyAccessorForPropertyPath, String.class);
            method.setAccessible(true);
            return method.invoke(bw, propertyName);
        } catch (Exception e) {
//            e.printStackTrace();
        }
        return null;

    }

//    private static Object getFieldValue(Object wrappedInstance, String fieldName) {
//        Field field = null;
//        try {
//            field = wrappedInstance.getClass().getDeclaredField(fieldName);
//            field.setAccessible(true);
//            return field.get(wrappedInstance);
//        } catch (NoSuchFieldException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
    public static Object getFieldValue(Object obj, String fieldName) throws Exception {
        Field f = null;
        if (obj instanceof Field) {
            f = (Field) obj;
        } else {
            Method method = null;
            Class cs = obj.getClass();

            while (cs != null) {
                try {
                    f = cs.getDeclaredField(fieldName);
                    cs = null;
                } catch (Exception var6) {
                    cs = cs.getSuperclass();
                }
            }
        }

        f.setAccessible(true);
        return f.get(obj);
    }
}
