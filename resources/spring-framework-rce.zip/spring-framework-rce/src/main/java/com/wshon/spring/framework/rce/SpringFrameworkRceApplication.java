package com.wshon.spring.framework.rce;

import org.apache.catalina.loader.ParallelWebappClassLoader;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintStream;
import java.io.PrintWriter;

@SpringBootApplication
@RestController
public class SpringFrameworkRceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringFrameworkRceApplication.class, args);
    }

    @RequestMapping({"/"})
    public String index(User user) {
        return "ok";
    }

    @RequestMapping({"/school"})
    public String school(School school) {
        return "ok";
    }
    @RequestMapping({"/demo2"})
    public void demo2(HttpServletRequest request, HttpServletResponse response) throws Exception {
        java.util.HashSet set = new java.util.HashSet<Object>();
        User initarget = new User();
        initarget.setUsername("wshon");
        Object target = demo2.applyGetChain(initarget, "");
        boolean debug = false;
        demo2 demo = new demo2();
        PrintWriter out = response.getWriter();
        demo.processClass(target, out, set, "", 0, debug);
    }

    @RequestMapping({"/demo"})
    public void student(HttpServletRequest request, HttpServletResponse response) throws Exception {
        java.util.HashSet set = new java.util.HashSet<Object>();
        School school = new School();
        school.setName("beijing");
        School.Student student = new School.Student();
        student.setName("wangshuai");
        School.Age age = new School.Age();
        age.setAge(18);
        student.setAge(age);
        school.setStudent(student);
        Object target = demo2.applyGetChain(school,"");
        boolean debug = false;
        demo2 demo = new demo2();
        PrintWriter out = response.getWriter();
        demo.processClass(target, out, set, "", 0, debug);
    }


}
