package com.wshon.spring.framework.Introspection;

/**
 * @ClassName: BeanB
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/11 20:19
 * @Version: v1.0.0
 * @Description:
 **/
public class BeanB {
    public String name;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

}
