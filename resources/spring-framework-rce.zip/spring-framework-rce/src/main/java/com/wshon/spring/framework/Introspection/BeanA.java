package com.wshon.spring.framework.Introspection;

/**
 * @ClassName: Beand
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/11 20:19
 * @Version: v1.0.0
 * @Description:
 **/
public class BeanA {
    public int id;
    public BeanB beanB;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BeanB getBeanB() {
        return beanB;
    }

    public void setBeanB(BeanB beanB) {
        this.beanB = beanB;
    }
}
