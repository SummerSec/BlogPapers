package com.wshon.spring.framework.rce;

import org.springframework.beans.BeanWrapperImpl;

/**
 * @ClassName: Test
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/8 14:41
 * @Version: v1.0.0
 * @Description:
 **/
public class Test {
    public static void main(String[] args) throws Exception {
        java.util.HashSet set = new java.util.HashSet<Object>();
        School school = new School();
        school.setName("beijing");
        School.Student student = new School.Student();
        student.setName("wangshuai");
        School.Age age = new School.Age();
        age.setAge(18);
        student.setAge(age);
        school.setStudent(student);
        Object target = demo.applyGetChain(school,"");
        boolean debug = false;
        demo demo = new demo();
        demo.processClass(target, System.out, set, "", 0, debug);
    }
}
