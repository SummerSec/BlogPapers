package com.wshon.spring.framework.rce;

/**
 * @ClassName: Use
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/6 17:51
 * @Version: v1.0.0
 * @Description:
 **/
public class Use {
    public static void main(String[] args) throws Exception {
        java.util.HashSet set = new java.util.HashSet<Object>();
        User initarget = new User();
        initarget.setUsername("wshon");
        Object target = demo.applyGetChain(initarget, "");
        boolean debug = false;
        demo demo = new demo();
        demo.processClass(target, System.out, set, "", 0, debug);

    }
}
