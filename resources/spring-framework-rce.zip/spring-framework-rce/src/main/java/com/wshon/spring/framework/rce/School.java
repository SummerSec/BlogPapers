package com.wshon.spring.framework.rce;

/**
 * @ClassName: School
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/8 14:39
 * @Version: v1.0.0
 * @Description:
 **/
public class School {
    String name;
    Student student;
   // TODO 添加setter和getter方法
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
    public static class Student {
        String name;

        Age age;
        public Age getAge() {
            return age;
        }
        public void setAge(Age age) {
            this.age = age;
        }
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
    }
    public static class Age {
        int age;
        public int getAge() {
            return age;
        }
        public void setAge(int age) {
            this.age = age;
        }
    }

}
