package com.wshon.spring.framework.Introspection;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.PropertyAccessorUtils;

/**
 * @ClassName: TestM
 * @Description: TODO
 * @Author: Summer
 * @Date: 2022/4/11 20:21
 * @Version: v1.0.0
 * @Description:
 **/
public class TestM {
    public static void main(String[] args) {
        TestBean tb = new TestBean();
        BeanWrapper bw = new BeanWrapperImpl(tb);
        bw.isReadableProperty("name");//判断name属性是否可读
        bw.setPropertyValue("name", "tom"); //设置name属性的值为tom
        bw.getPropertyValue("int2"); //取得属性
        //当然，最强大的是能嵌套设置属性，如：
        //tb中有个spouse的属性，也为TestBean，这样
        bw.setPropertyValue("beanA", "tom");
        //等价于tb.getSpouse().setName("tom");
//        PropertyAccessorUtils //属性访问工具类


    }
}
